// BEGIN: Footer Menu61 JS

$(document).ready(function(){
$('.SubMenus61 > div:only-child').each(function(){
 if($(this).css('display') == 'none')
  $(this).parents('.MenuContainer61').remove();
});
$('.SubMenus61 > div').each(function(){
if($(this).css('display') == 'none')
$(this).remove();
});
$('.SubMenus61 > div').each(function(){
if($(this).css('display') != 'none')
$(this).append("<span class=\'SubMenuFooterBullet61\'><i class=\'fa fa-circle\'></i></span>");
});
$('.SubMenus61 div:last-of-type').each(function(){
$(this).find('.SubMenuFooterBullet61').css('display', 'none');
});
$('.SubMenus61 > div a').each(function(){
if($(this).is(':empty'))
$(this).parents('.MenuContainer61').remove();
});   
$('.Menus61 > a').each(function(){
if(jQuery(this).attr("href") == "#")
  $(this).css('pointer-events', 'none');
});
});

// END: Footer Menu61 JS



// BEGIN: Sticky Menu on Mobile

$(document).scroll(function(){
	if ($(document).width() < 769) {
		if ($(document).scrollTop()>60){
			$('.c3').addClass('TopBlackBar');
			$('.google_div').addClass('TopBlackBar');
		}
		else {
			$('.c3').removeClass('TopBlackBar');
			$('.google_div').removeClass('TopBlackBar');
		}
	}
});

$(document).ready(function(){
	if ($(document).width() < 768) {
		$('.open').css('height', $(window).height());
	}
});

// END: Sticky Menu on Mobile


// BEGIN: New Responsive Menu

(function($) {

  $.fn.menumaker = function(options) {
      
      var cssmenu = $(this), settings = $.extend({
        title: "Menu",
        format: "dropdown",
        sticky: false
      }, options);

      return this.each(function() {
        cssmenu.prepend('<div id="menu-button">' + '≡' + '</div>');
        $(this).find("#menu-button").on('click', function(){
          $(this).toggleClass('menu-opened');
          var mainmenu = $(this).next('ul');
          if (mainmenu.hasClass('open')) { 
            mainmenu.hide().removeClass('open');
          }
          else {
            mainmenu.show().addClass('open');
            if (settings.format === "dropdown") {
              mainmenu.find('ul').show();
            }
          }
        });

        cssmenu.find('li ul').parent().addClass('has-sub');

        multiTg = function() {
          cssmenu.find(".has-sub").prepend('<span class="submenu-button"></span>');
          cssmenu.find('.menubodyhorizontal').on('click', function() {
            $(this).toggleClass('submenu-opened');
            if ($(this).siblings('ul').hasClass('open')) {
              $(this).siblings('ul').removeClass('open').hide();
            }

            else {
              $(this).siblings('ul').addClass('open').show();
            }
          });
		     cssmenu.find('.submenu-button').on('click', function() {
            $(this).parents('li').toggleClass('submenu-opened');
            if ($(this).siblings('ul').hasClass('open')) {
              $(this).siblings('ul').removeClass('open').hide();
            }

            else {
              $(this).siblings('ul').addClass('open').show();
            }
          });
        };

        if (settings.format === 'multitoggle') multiTg();
        else cssmenu.addClass('dropdown');

        if (settings.sticky === true) cssmenu.css('position', 'fixed');

        resizeFix = function() {
          if ($( window ).width() > 768) {
            cssmenu.find('ul').show();
          }

          if ($(window).width() <= 768) {
            cssmenu.find('ul').hide().removeClass('open');
          }
        };
        resizeFix();
        return $(window).on('resize', resizeFix);

      });
  };
})(jQuery);

(function($){
$(document).ready(function(){

$(document).ready(function() {
  $("#cssmenu").menumaker({
    title: "Menu",
    format: "multitoggle"
  });

  $("#cssmenu").prepend("");

var foundActive = false, activeElement, linePosition = 0, menuLine = $("#cssmenu #menu-line"), lineWidth, defaultPosition, defaultWidth;

$("#cssmenu > ul > li").each(function() {
  if ($(this).hasClass('active')) {
    activeElement = $(this);
    foundActive = true;
  }
});

if (foundActive === false) {
  activeElement = $("#cssmenu > ul > li").first();
}

defaultWidth = lineWidth = activeElement.width();

defaultPosition = linePosition = activeElement.position().left;

menuLine.css("width", lineWidth);
menuLine.css("left", linePosition);

$("#cssmenu > ul > li").hover(function() {
  activeElement = $(this);
  lineWidth = activeElement.width();
  linePosition = activeElement.position().left;
  menuLine.css("width", lineWidth);
  menuLine.css("left", linePosition);
}, 
function() {
  menuLine.css("left", defaultPosition);
  menuLine.css("width", defaultWidth);
});

});


});
})(jQuery);

$(document).ready(function(){
$(window).load(function(){
$('a.menubodyhorizontal[href*="#"]').prev('.submenu-button').css('visibility', 'visible');
});
});

// BEGIN: New Responsive Menu


// BEGIN: Weather 
/*
<div id="plemx-root"></div> 
  <script type="text/javascript"> 

  var _plm = _plm || [];
  _plm.push(['_btn', 16904]); 
  _plm.push(['_loc','ustx1348']);
  _plm.push(['location', document.location.host ]);

  (function(d,e,i) {
  if (d.getElementById(i)) return;
  var px = d.createElement(e);
  px.type = 'text/javascript';
  px.async = true;
  px.id = i;
  px.src = ('https:' == d.location.protocol ? 'https:' : 'http:') + '//widget.twnmm.com/js/btn/pelm.js?orig=en_ca';
  var s = d.getElementsByTagName('script')[0];

  var py = d.createElement('link');
  py.rel = 'stylesheet'
  py.href = ('https:' == d.location.protocol ? 'https:' : 'http:') + '//widget.twnmm.com/styles/btn/styles.css'

  s.parentNode.insertBefore(px, s);
  s.parentNode.insertBefore(py, s);
})(document, 'script', 'plmxbtn');</script>
*/
// END: Weather