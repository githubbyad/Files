function GetDateFormat(){return 'Fri, 15 July, 2009';}

function start(){checkLoginStatus('No');}

function GetLogo(){document.write('<a id="logo" href="https://americanpatriotdispatch.com/"><img class="img-fluid" BORDER=0 src="https://americanpatriotdispatch.com/2-3-2013-4-18-34-PM-9605156.jpg" title="LOGO: American Patriot Dispatch LLC"></a>');}

function GetLogoM(){document.write('');}

function hcCaption() {document.write('You are visitor:');}function hcShow() {return 'Yes';}function getHC2(myObj) {document.write('<div class="hitcounter"><script>hcCaption();<\/script> ' + myObj.hc.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + '</div>');}function getHC(myObj) {if (hcShow() == 'Yes') {getHC2(myObj);}}  

function HitCounter(){document.write('<script type="text/javascript" language="javascript" src="' + readCookie('AppServer') + 'get_site_counter.php?site=americanpatriotdispatch.com"><\/script>');}

function GetSandwichIconName(){document.write('MENU');}

function GetContactInformation(){document.write('<div class="contactbody">American Patriot Dispatch LLC 2080 Neeld Road, East Palestine, Ohio 44413-1475</div>');}

function GetCopyright(){document.write('© Copyright  <a href="/login.asp">American Patriot Dispatch LLC</a>.  All rights reserved.');}

function GetUnauthorisedAccessText() {document.write('<div id="divAccess" style="display:none"><center><font size=4><b>You have not logged in.</b></font><br><br><a href="#" onclick="return OpenLoginPopup();"><font size=4><b>Please click here to login.</b></font></a></center><div class="pageruler"><span style="FONT-SIZE: 0pt;">&nbsp;</span></div></div>');}

function GetAddThis(){document.write('<div class="addthis_toolbox addthis_default_style"><a href="https://addthis.com/bookmark.php?v=250" class="addthis_button_compact">Share</a><span class="addthis_separator"></span><a class="addthis_button_facebook"></a><a class="addthis_button_twitter"></a><a class="addthis_button_googlebuzz"></a><a class="addthis_button_email"></a><span class="addthis_separator"></span><a class="addthis_button_facebook_like"></a></div><script type="text/javascript" src="https://s7.addthis.com/js/250/addthis_widget.js"></script>');}

function GetComments(){document.write('');}

function GetTranslator(){document.write('<div id="google_translate_element"></div>\n<script>function googleTranslateElementInit() { new google.translate.TranslateElement({ pageLanguage: \'en\', layout: google.translate.TranslateElement.InlineLayout.SIMPLE  }, \'google_translate_element\');}<\/script>\n<script src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"><\/script>');}

function GetSearchBox(){document.write('<a href=https://americanpatriotdispatch.com/index0.htm?sname=target_search.asp class="sbinput"><img src="https://americanpatriotdispatch.com/lib/images/ptrans.gif" border=0></a>');}

function GetSearchBoxUser(FName){document.write('<a href=https://americanpatriotdispatch.com/index0.htm?sname=target_search.asp><img src=' + FName + ' border=0></a>');}

function SMThemeColor(){return 'Purple';}

function GetUserStyles(){document.write('<div id="UserStyles"><ul><li><a href="#">&nbsp;</a><ul><li><table cellpadding="0" cellspacing="0" border="0"><tr><td><a href="javascript:chooseStyle(\'americanpatriotdispatch_stylea\', 60);reloadiframe(\'IFrameContent\',\'americanpatriotdispatch_stylea\', 60);"><img title="Gray" border="0" src="https://americanpatriotdispatch.com/lib/images/style_grey.gif" /></a></td><td><a href="javascript:chooseStyle(\'americanpatriotdispatch_styleb\', 60);reloadiframe(\'IFrameContent\',\'americanpatriotdispatch_styleb\', 60);"><img title="Blue" border="0" src="https://americanpatriotdispatch.com/lib/images/style_blue.gif" /></a></td><td><a href="javascript:chooseStyle(\'americanpatriotdispatch_stylec\', 60);reloadiframe(\'IFrameContent\',\'americanpatriotdispatch_stylec\', 60);"><img title="Magenta" border="0" src="https://americanpatriotdispatch.com/lib/images/style_magenta.gif" /></a></td><td><a href="javascript:chooseStyle(\'americanpatriotdispatch_styled\', 60);reloadiframe(\'IFrameContent\',\'americanpatriotdispatch_styled\', 60);"><img title="Violet" border="0" src="https://americanpatriotdispatch.com/lib/images/style_violet.gif" /></a></td><td><a href="javascript:chooseStyle(\'americanpatriotdispatch_stylee\', 60);reloadiframe(\'IFrameContent\',\'americanpatriotdispatch_stylee\', 60);"><img title="Orange" border="0" src="https://americanpatriotdispatch.com/lib/images/style_orange.gif" /></a></td><td><a href="javascript:chooseStyle(\'americanpatriotdispatch_stylef\', 60);reloadiframe(\'IFrameContent\',\'americanpatriotdispatch_stylef\', 60);"><img title="Green" border="0" src="https://americanpatriotdispatch.com/lib/images/style_green.gif" /></a></td><td><a href="javascript:chooseStyle(\'americanpatriotdispatch_styleg\', 60);reloadiframe(\'IFrameContent\',\'americanpatriotdispatch_styleg\', 60);"><img title="Yellow" border="0" src="https://americanpatriotdispatch.com/lib/images/style_yellow.gif" /></a></td><td><a href="javascript:chooseStyle(\'americanpatriotdispatch_styleh\', 60);reloadiframe(\'IFrameContent\',\'americanpatriotdispatch_styleh\', 60);"><img title="Red" border="0" src="https://americanpatriotdispatch.com/lib/images/style_red.gif" /></a></td><td><a href="javascript:chooseStyle(\'americanpatriotdispatch_stylei\', 60);reloadiframe(\'IFrameContent\',\'americanpatriotdispatch_stylei\', 60);"><img title="Cyan" border="0" src="https://americanpatriotdispatch.com/lib/images/style_cyan.gif" /></a></td><td style="padding-right:0px;"><a href="javascript:chooseStyle(\'americanpatriotdispatch_stylej\', 60);reloadiframe(\'IFrameContent\',\'americanpatriotdispatch_stylej\', 60);"><img title="Brown" border="0" src="https://americanpatriotdispatch.com/lib/images/style_brown.gif" /></a></td></tr></table></li></ul></li></ul></div>');}

function GetGoogleAnalytics(link) {document.write('');}

function GetArticleDate(ArticleDate) {var Article_Timestamp = 0;if (ArticleDate == "") { document.write(''); }else if (Article_Timestamp == 0){GetDate(ArticleDate, "Fri, Jul 15, 2009");}else {GetTimeAgo(ArticleDate, 0, 0, "Fri, Jul 15, 2009", 300);}}

function GetGoogleCustomSearch() { document.write(''); }

WebFontConfig = {google: { families: [ 'Roboto+Condensed:300italic,400italic,700italic,400,300,700:latin','Oswald:400,300,700:latin','Dosis:200,300,400,500,600,700,800:latin','Open+Sans:300,400,600,700,800' ]}};(function() {var wf = document.createElement('script');wf.src = ('https:' == document.location.protocol ? 'https' : 'http') + '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';wf.type = 'text/javascript';wf.async = 'true';var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(wf, s);})();

function SParameters(){return '90';}

