function MenusDefault(){document.write('');}
function MenusHorizontal(){document.write('<table align=center border=0 cellPadding=0 cellSpacing=0><tr><td align=center><script type="text/javascript" language="JavaScript" src="https://americanpatriotdispatch.com/horizontal3_americanpatriotdispatch.js?v=39143981481"></script></td></tr></table>');}

function MenusVertical(){document.write('');}

