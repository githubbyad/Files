function GetTooltip1(){Tipped.create('.t1', { ajax: false, closeButton: false, showOn: 'mouseover', skin: 'yellow', fixed: true, target: 'mouse', maxWidth: 500  });}

